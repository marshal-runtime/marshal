# Agentic Debugger — Quick Reference

CLI tool and MCP server for interactive debugging via DAP. Supports **JavaScript/TypeScript**, **Python**, and **C#/.NET**. All output is structured JSON.

---

## Usage Modes

| Mode | Invocation |
|------|------------|
| **CLI** | `agentic-debugger <command> [options]` |
| **MCP Server** | `agentic-debugger serve --transport stdio` |

## Global Flags

`-s, --session <id>` · `--verbose` · `--pretty` · `--version` · `--help`

---

## Commands

### Session Lifecycle

```bash
# Launch (auto-detects language from extension)
agentic-debugger launch ./app.ts [--language <lang>] [--args ...] [--cwd <dir>] [--env K=V...] [--stop-on-entry]

# Attach to running process
agentic-debugger attach --language <lang> [--address host:port | --pid <pid>]

# End session
agentic-debugger disconnect -s <id> [--terminate]
agentic-debugger terminate -s <id>
```

### Breakpoints

```bash
# Line breakpoint (with optional condition, hit-count, or logpoint)
agentic-debugger breakpoint set <file:line> -s <id> [--condition <expr>] [--hit-condition <expr>] [--log-message <msg>]

# Function breakpoint
agentic-debugger breakpoint set --function <name> -s <id>

# Remove / list
agentic-debugger breakpoint remove <file:line> -s <id>
agentic-debugger breakpoint remove --all -s <id>
agentic-debugger breakpoint list -s <id>

# Exception breakpoints (filters: all | caught | uncaught)
agentic-debugger exception-breakpoints set --filter uncaught -s <id>
```

### Execution Control

```bash
agentic-debugger continue -s <id> [--thread <tid>]
agentic-debugger step <over|into|out> -s <id> [--thread-id <tid>]
agentic-debugger step restart-frame --frame-id <fid> -s <id>
agentic-debugger pause -s <id> [--thread <tid>]
agentic-debugger set-next-statement <file:line> -s <id>
```

### Inspection

```bash
agentic-debugger variables -s <id> [--frame <id>] [--ref <num>] [--depth <n>]
agentic-debugger callstack -s <id> --thread <tid>
agentic-debugger threads -s <id>
agentic-debugger evaluate "<expr>" -s <id> [--frame <id>] [--context watch|repl|hover] [--safe-mode]

# Watch expressions
agentic-debugger watch add|remove|list|evaluate -s <id>
```

### Interactive Mode

```bash
agentic-debugger repl -s <id>                          # Interactive dbg> prompt
```

---

## Typical Workflow

```bash
# 1. Launch with stop-on-entry
agentic-debugger launch ./app.ts --stop-on-entry        # → sessionId: sess-1

# 2. Set exception breakpoints + line breakpoint
agentic-debugger exception-breakpoints set --filter uncaught -s sess-1
agentic-debugger breakpoint set src/handler.ts:42 -s sess-1

# 3. Run to breakpoint
agentic-debugger continue -s sess-1

# 4. Inspect state
agentic-debugger callstack --thread 1 -s sess-1
agentic-debugger variables --frame 0 --depth 2 -s sess-1
agentic-debugger evaluate "response.data" -s sess-1

# 5. Step through code
agentic-debugger step over -s sess-1
agentic-debugger step into -s sess-1

# 6. Clean up
agentic-debugger disconnect -s sess-1 --terminate
```

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `AGENTIC_LOG_LEVEL` | `debug` / `info` / `warn` / `error` (default: `info`) |
| `AGENTIC_LOG_DIR` | Log file directory (default: `./logs`) |
| `AGENTIC_JSDEBUG_PATH` | Path to js-debug `dapDebugServer.js` (must point to the file inside `js-debug/src/` alongside companion `.wasm` files) |
| `AGENTIC_VSDBG_PATH` | Path to `vsdbg.exe` binary |
| `AGENTIC_DEBUGPY_PATH` | Path to debugpy module |
| `AGENTIC_NETCOREDBG_PATH` | Path to netcoredbg binary |
| `AGENTIC_PYTHON_PATH` | Python interpreter path |
| `AGENTIC_SAFE_MODE` | Enable expression safety checks (default: `true`) |

---

## Attach by Language

### TypeScript / JavaScript — Node.js V8 Inspector (recommended)

```bash
# Attach to a Node.js process started with --inspect or --inspect-brk.
# Under the hood the CLI routes this to js-debug's pwa-node adapter.
agentic-debugger attach --language javascript --address 127.0.0.1:9229
```

### TypeScript / JavaScript — CDP (Chrome, Edge, WebView2)

> **NOT CURRENTLY SUPPORTED in standalone CLI.** Tracked as bug 4.
> js-debug's `dapDebugServer.js` requires VS Code's multi-session host to
> bind to browser targets. `agentic-debugger attach --type chrome|msedge`
> returns a clear error. Workarounds:
>
> * For Node.js, use the V8 inspector path above.
> * For browsers/WebView2, attach via VS Code's JS debugger directly.

### C# / .NET Core, .NET 5+ — netcoredbg (preferred)

```bash
# netcoredbg is a stdio adapter — attach by PID.
# Find the PID: tasklist | findstr MyApp  (Windows)
#               ps aux | grep MyApp       (Linux/macOS)

agentic-debugger attach --language csharp --pid 12345
```

Under the hood: spawns `netcoredbg --interpreter=vscode`, then drives DAP `initialize` + `attach { processId }` + `configurationDone`. If netcoredbg isn't installed, the CLI falls back to vsdbg → clr-debug (vsdbg almost always fails its Microsoft license check outside VS Code; the CLI silently continues to the next adapter).

### C# / .NET Framework 4.x — clr-debug (Windows only)

```bash
# clr-debug uses ICorDebug and ships prebuilt with the npm package.
agentic-debugger attach --language csharp --pid 12345 --type clr
```

> **Note:** `--address` is not supported for C# — none of the .NET adapters listen on TCP.

---

## Tips

1. **`--session` and `--thread-id` are optional everywhere.** The CLI auto-selects the most recent session and the last stopped thread. Supply them only to disambiguate.
2. **Use `--stop-on-entry`** to set breakpoints before the program runs past them.
3. **Set exception breakpoints first** — catch errors at their origin.
4. **Use conditional breakpoints** in loops to skip uninteresting iterations.
5. **Start with `--depth 1`** for variables — drill deeper only as needed.
6. **Use logpoints** (`--log-message`) to trace without pausing.
7. **Multiple sessions** — each `launch` gets a unique `sessionId`; debug concurrently.
8. **C# requires `--pid`** — none of the .NET adapters support `--address`. Use `tasklist` / `ps` to find the PID. Pass `--type clr` for .NET Framework 4.x.
9. **CDP (`--type chrome|msedge`) is unsupported** in standalone CLI — bug 4. Use V8 inspector attach for Node, VS Code for browsers.
10. **If attach fails**, check the error `code` field: `CONNECTION_REFUSED` means the target isn't running or the port is wrong; `ADAPTER_NOT_FOUND` means the debug adapter binary is missing (run `npm install` to trigger postinstall).
