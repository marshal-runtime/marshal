# Marshal Agentic Debugger Extension

Independent Marshal Runtime Extension, CLI, MCP server, DAP engine, native adapter host, and Monaco debugger UI. The repository does not import Marshal application internals and can be built and tested without the Marshal source tree.

## Repository outputs

| Surface | Output |
| --- | --- |
| Marshal manifest | `runtime-extension.json` |
| CommonJS activation | `dist/runtime-extension.cjs` |
| Portable runtime bridge | `src/runtime/` and `@marshal/agentic-debugger-extension/runtime` |
| Native DAP host adapter | `NativeDebuggerHostAdapter` from `@marshal/agentic-debugger-extension/native` |
| Monaco React UI | `@marshal/agentic-debugger-extension/ui` |
| Existing library API | `@marshal/agentic-debugger-extension/core` |
| Existing CLI | `agentic-debugger` |
| Existing MCP server | `agentic-debugger serve --transport stdio` |

The activation bundle is intentionally host-neutral. Marshal or another host binds a typed `DebuggerHostAdapter` under `DEBUGGER_HOST_ADAPTER_SERVICE` in the activation context's service container. The extension resolves that service for each debugger operation, so hosts can replace the binding without reactivating the extension. `NativeDebuggerHostAdapter` is the default Node implementation backed by the repository's existing DAP, adapter, security, redaction, and session behavior.

### Marshal output schema contract

Every runtime capability declares the full strict bridge and concrete result schema used for search and invocation. Call-stack frames accept either the normalized source-path string used by the UI and RPC host adapters or a strict DAP `Source` object returned by the native adapter. UI actions and tools use a compact, strict top-level projection of the same envelope and concrete result fields; nested debugger snapshots and collections stay behind typed object/array boundaries so the packed application descriptor remains within Marshal's 64 KiB and depth-12 UI payload limits.

Two protocol-defined nested fields remain intentionally opaque: DAP `Source.adapterData` and debugger event `body`. They are explicit named fields rather than catch-all object properties. DAP `Module` permits adapter-defined top-level columns, but Marshal's strict output contract cannot safely admit undeclared keys; this extension declares the standard DAP module fields only, so adapters must omit or normalize custom module columns before returning them.

## Install, build, run, and test

```powershell
npm install
npm run typecheck
npm run lint
npm run test
npm run build
npm run test:acceptance
npm run test:manifest
node .\dist\cli.mjs --help
```

Adapter downloads are never hidden inside normal installation. Run `npm run provision:adapters` only when you explicitly want the existing adapter provisioning script. Python requires `debugpy`; .NET adapters can be provided with `AGENTIC_NETCOREDBG_PATH`, `AGENTIC_CLR_DEBUG_PATH`, or `AGENTIC_VSDBG_PATH`.

See [Marshal Runtime Extension Setup](docs/marshal-runtime-extension.md) and [Migration Note](MIGRATION.md).

For Runtime TypeScript blocks, the injectable service is
`@marshal/agentic-debugger:debugger` (`TypeSymbols.debugger`). Access it with
`AppServices.getDebugger().invoke(...)`; its published contract is
[`contracts/IDebugger.d.ts`](contracts/IDebugger.d.ts). The result is a
generic capability envelope, so use each capability's existing schema for
`result.output.value`.

## Features

- **Debug Session Management** — Launch, attach, restart, and terminate debug sessions
- **Breakpoint Control** — Line, conditional, function, data, and exception breakpoints
- **Step Execution** — Step into, over, out, reverse continue, and restart frame
- **Variable Inspection** — Inspect variables, scopes, and nested object properties
- **Expression Evaluation** — Evaluate expressions in paused stack frame context
- **Call Stack & Threads** — Navigate stack frames and inspect thread states
- **Concurrent Sessions** — Manage multiple debug sessions simultaneously
- **Multi-Language Support** — JavaScript/TypeScript, Python, and C#/.NET
- **MCP Server Mode** — Expose all 31 debugging tools via the Model Context Protocol
- **Structured JSON Output** — All CLI output is machine-readable JSON
- **Security Built-In** — Expression safety checks, value redaction, and process guards

## Quick Start

### Install the CLI package

```bash
npm install -g @marshal/agentic-debugger-extension
```

Requires Node.js >= 18.0.0.

### CLI Usage

```bash
# Launch a debug session
agentic-debugger launch --program ./app.js

# Launch with explicit language
agentic-debugger launch --program ./app.py --language python

# Attach to a running Node.js process (V8 inspector port)
agentic-debugger attach --language javascript --address 127.0.0.1:9229

# Attach to a running .NET Core / .NET 5+ process
agentic-debugger attach --language csharp --pid 12345

# Attach to a running .NET Framework 4.x process (Windows only)
agentic-debugger attach --language csharp --pid 12345 --type clr

# Set a breakpoint (--session is optional — defaults to the most recent session)
agentic-debugger breakpoint set --file app.js --line 10

# Set a conditional breakpoint
agentic-debugger breakpoint set --file app.js --line 10 --condition "x > 5"

# Continue execution (defaults to the last stopped thread)
agentic-debugger continue

# Step over (defaults to the last stopped thread)
agentic-debugger step over

# Inspect variables
agentic-debugger variables --ref 100

# Get call stack
agentic-debugger callstack

# List threads
agentic-debugger threads

# Evaluate an expression
agentic-debugger evaluate "user.name"

# Set exception breakpoints
agentic-debugger exception-breakpoints --filters uncaught

# Pause a running program
agentic-debugger pause

# Terminate the debug session
agentic-debugger terminate

# Interactive REPL mode
agentic-debugger repl
```

> **Session and thread defaults.** All commands after `attach` accept an optional
> `--session <id>` flag. When omitted, the CLI auto-selects the most recently
> created session — handy for one-shot scripts and AI agents that don't want to
> track session IDs. Similarly, thread-scoped commands (`callstack`, `continue`,
> `pause`, `step`, `goto`) accept `--thread-id <n>`; when omitted, the session
> host injects the most recent `stopped` event's thread ID. Adapters like
> netcoredbg report OS thread IDs (5-digit) that an agent would otherwise have
> to discover by calling `threads` first.

> **Browser / CDP attach (`--type chrome|msedge`) is not currently supported in
> the standalone CLI.** js-debug's `dapDebugServer.js` requires VS Code's
> multi-session infrastructure to bind to Chrome/Edge/WebView2 CDP targets.
> Tracked as bug 4. For Node.js attach, use the JS V8 inspector path above
> (`node --inspect-brk=PORT` + `attach --language javascript --address …`).

### MCP Server Mode

Start the debugger as an MCP server for AI agent integration:

```bash
# stdio transport (for local agents)
agentic-debugger serve --transport stdio

# SSE transport (for remote agents)
agentic-debugger serve --transport sse --port 3000
```

#### MCP Client Configuration

**Roo Code** (`.roo/mcp.json`):

```json
{
  "mcpServers": {
    "agentic-debugger": {
      "command": "agentic-debugger",
      "args": ["serve", "--transport", "stdio"]
    }
  }
}
```

**Cline** (VS Code `settings.json`):

```json
{
  "cline.mcpServers": {
    "agentic-debugger": {
      "command": "agentic-debugger",
      "args": ["serve", "--transport", "stdio"]
    }
  }
}
```

**Cursor** (Settings → MCP):

```json
{
  "mcpServers": {
    "agentic-debugger": {
      "command": "agentic-debugger",
      "args": ["serve", "--transport", "stdio"]
    }
  }
}
```

See the [MCP Quickstart Guide](docs/mcp-quickstart.md) for full configuration details including SSE transport.

## Supported Languages

| Language | Preferred adapter | Fallbacks | Install |
|----------|-------------------|-----------|---------|
| JavaScript | js-debug (pwa-node) | — | Run `npm run provision:adapters`, use VS Code's copy, or set `AGENTIC_JSDEBUG_PATH` |
| TypeScript | js-debug (pwa-node) | — | Same as JavaScript |
| Python | debugpy | — | `pip install debugpy` |
| C# / .NET Core / .NET 5+ | netcoredbg | vsdbg → clr-debug | [Samsung/netcoredbg](https://github.com/Samsung/netcoredbg) |
| C# / .NET Framework 4.x (Windows) | clr-debug (ICorDebug) | — | Build the adapter locally or set `AGENTIC_CLR_DEBUG_PATH`; pass `--type clr` |

Notes:

* For .NET Core targets the native runtime host selects netcoredbg by default. vsdbg remains explicit opt-in, and clr-debug is attach-only for .NET Framework.
* **Browser/CDP attach (`--type chrome|msedge`) is not supported in standalone CLI** — see the "Session and thread defaults" call-out above. Tracked as bug 4.

Language is auto-detected from file extensions (`.js`, `.ts`, `.py`, `.cs`) or can be specified explicitly with `--language`.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                        CLI / MCP Layer                       │
│  CLI commands (commander)  │  MCP tools (@modelcontextprotocol/sdk)  │
├──────────────────────────────────────────────────────────────┤
│                      Session Manager                         │
│  Concurrent sessions  │  Session lifecycle  │  Event routing │
├──────────────────────────────────────────────────────────────┤
│                      DAP Client Layer                        │
│  DapClient  │  DapFramer  │  DapRouter  │  Transports       │
├──────────────────────────────────────────────────────────────┤
│                      Adapter Layer                           │
│  BaseAdapter  │  js-debug  │  debugpy  │  netcoredbg / vsdbg / clr-debug │
└──────────────────────────────────────────────────────────────┘
```

**CLI / MCP Layer** — User-facing interfaces. The CLI provides 16 commands for direct terminal use. The MCP server exposes 31 tools for AI agent consumption. Both produce structured JSON output.

**Session Manager** — Manages concurrent debug sessions with unique IDs. Handles session lifecycle (create, pause, resume, terminate) and routes DAP events.

**DAP Client Layer** — Implements the Debug Adapter Protocol over stdio and TCP transports. The `DapFramer` handles Content-Length message framing, the `DapRouter` dispatches responses and events, and the `DapClient` provides the typed request/response API.

**Adapter Layer** — Abstracts language-specific debug servers behind a common interface. Each adapter knows how to spawn its debug server, construct launch/attach arguments, and report its capabilities.

## Documentation

- [MCP Quickstart](docs/mcp-quickstart.md) — Configure AI agents to use the debugger
- [Adapter Development](docs/adapter-development.md) — Add support for new languages
- **Language Guides:**
  - [TypeScript/JavaScript Debugging](docs/guides/typescript-debugging.md)
  - [Python Debugging](docs/guides/python-debugging.md)
  - [C#/.NET Debugging](docs/guides/csharp-debugging.md)
- **Example Scenarios:**
  - [Debugging a Null Reference](docs/examples/null-reference.md)
  - [Debugging an Infinite Loop](docs/examples/infinite-loop.md)
  - [Debugging a Race Condition](docs/examples/race-condition.md)
- **Skills:**
  - [Debugging Strategy](docs/skills/debugging-strategy.md)
  - [Common Workflows](docs/skills/common-workflows.md)
  - [Best Practices](docs/skills/best-practices.md)

## Configuration

Configuration can be provided via environment variables or a `.agentic-debugger.json` file:

| Variable | Description | Default |
|----------|-------------|---------|
| `AGENTIC_LOG_LEVEL` | Log level (`debug`, `info`, `warn`, `error`) | `info` |
| `AGENTIC_LOG_DIR` | Directory for log files | `./logs` |
| `AGENTIC_JSDEBUG_PATH` | Path to js-debug binary | Auto-detected |
| `AGENTIC_DEBUGPY_PATH` | Path to debugpy module | Auto-detected |
| `AGENTIC_NETCOREDBG_PATH` | Path to netcoredbg binary (preferred for .NET Core) | Auto-detected |
| `AGENTIC_VSDBG_PATH` | Path to vsdbg binary (fallback; license-locked to VS Code) | Auto-detected |
| `AGENTIC_CLR_DEBUG_PATH` | Path to clr-debug.exe binary (.NET Framework) | Required unless built at the conventional local path |
| `AGENTIC_SAFE_MODE` | Enable expression safety checks | `true` |
| `AGENTIC_REDACT_PATTERNS` | Comma-separated redaction patterns | Built-in defaults |

See [`.env.example`](.env.example) for all options.

## Development

```bash
# Install dependencies
npm install

# Build
npm run build

# Run tests
npm test

# Unit tests only
npm run test:unit

# Integration tests
npm run test:integration

# Opt in to local netcoredbg process tests
$env:AGENTIC_RUN_NETCOREDBG_INTEGRATION = "1"
npm run test:integration

# E2E tests
npm run test:e2e

# Type check
npm run typecheck

# Lint
npm run lint

# Format
npm run format

# Run all checks
npm run check
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Make your changes and add tests
4. Run `npm run check` to verify all checks pass
5. Commit your changes (`git commit -m 'Add my feature'`)
6. Push to the branch (`git push origin feature/my-feature`)
7. Open a Pull Request

See the [Adapter Development Guide](docs/adapter-development.md) for adding support for new languages.

## License

[MIT](LICENSE)
