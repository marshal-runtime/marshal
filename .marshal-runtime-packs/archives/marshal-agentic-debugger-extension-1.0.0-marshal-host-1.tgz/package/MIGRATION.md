# Migration Note

This repository was independently assembled from the Agentic Debugger source at:

`Q:\src\agentic-debugger-copilot-integration`

The migration harvested the runtime plan from `Q:\src\agentic-debugger-copilot-plan\PLAN.md`, the Monaco UI work from `Q:\src\agentic-debugger-copilot-ui`, and the contract review from `Q:\src\agentic-debugger-copilot-review\REVIEW.md`.

The original Agentic Debugger remains available through the preserved CLI, MCP, DAP, adapter, security, logging, configuration, schemas, and session modules in this repository. Existing command names and MCP operations remain present. The new Marshal boundary adds typed scoped capabilities, execution-block records, panel/tab lifecycle coordination, and a UI bridge without changing the source repositories.

Marshal application code is not copied or modified. Public contract shapes are represented by portable interfaces, and host-specific process authority is isolated behind `DebuggerHostAdapter`.
